package edu.mum.cs.cs425.demowebapps.elibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElibraryApplicationTests {

    @Test
    void contextLoads() {
    }

}
